import { ReactWidget, UseSignal } from '@jupyterlab/apputils';
import { FileBrowser } from '@jupyterlab/filebrowser';
import { folderIcon, LabIcon, fileIcon } from '@jupyterlab/ui-components';
import { Signal } from '@lumino/signaling';
import * as React from 'react';
import { FavoritesManager } from './manager';
import { IFavorites } from './token';
import {
  getFavoritesIcon,
  getName,
  getPinnerActionDescription,
  mergePaths,
} from './utils';

const FAVORITE_MAIN_CLASS = 'jp-Favorites';
const FAVORITE_ITEM_CLASS = 'jp-Favorites-item';
const FAVORITE_ITEM_ICON_CLASS = 'jp-Favorites-itemIcon';
const FAVORITE_ITEM_TEXT_CLASS = 'jp-Favorites-itemText';
const FAVORITE_ITEM_PINNER_CLASS = 'jp-Favorites-pinner';
const FAVORITE_BREADCRUMB_ICON_CLASS = 'jp-Favorites-BreadCrumbs-Icon';
const FAVORITE_HEADER_CLASS = 'jp-Favorites-header';
const FAVORITE_CONTAINER_CLASS = 'jp-Favorites-container';
const FILEBROWSER_HEADER_CLASS = 'jp-FileBrowser-header';

const BREADCRUMB_CLASS = 'jp-BreadCrumbs';

namespace types {
  export type FavoriteComponentProps = {
    favorite: IFavorites.Favorite;
    handleClick: (favorite: IFavorites.Favorite) => void;
  };

  export interface IFavoritesBreadCrumbProps {
    currentPath: string;
    manager: FavoritesManager;
    handleClick: (path: string) => void;
  }
}

const FavoriteComponent = (props: types.FavoriteComponentProps) => {
  const { favorite, handleClick } = props;
  let displayName = getName(favorite.path);
  if (favorite.name) {
    displayName = favorite.name;
  }

  let FavoriteIcon: LabIcon;
  if (favorite.iconLabel) {
    FavoriteIcon = LabIcon.resolve({ icon: favorite.iconLabel });
  } else {
    // Fallback for favorite using the v1 setting definition
    if (favorite.contentType === "directory") {
      FavoriteIcon = folderIcon;
    } else {
      FavoriteIcon = fileIcon;
    }
  }

  return (
    <div
      className={FAVORITE_ITEM_CLASS}
      title={mergePaths(favorite.root, favorite.path)}
      onClick={(e) => {
        handleClick(favorite);
      }}
    >
      <FavoriteIcon.react className={FAVORITE_ITEM_ICON_CLASS} tag="span" />
      <span className={FAVORITE_ITEM_TEXT_CLASS}>{displayName}</span>
    </div>
  );
};

const FavoritesBreadCrumbs: React.FunctionComponent<types.IFavoritesBreadCrumbProps> = (
  props: types.IFavoritesBreadCrumbProps
): JSX.Element => {
  if (props.currentPath) {
    const FavoriteIcon = getFavoritesIcon(
      props.manager.hasFavorite(props.currentPath)
    );
    return (
      <div
        className={FAVORITE_ITEM_PINNER_CLASS}
        title={getPinnerActionDescription(
          props.manager.hasFavorite(props.currentPath)
        )}
        onClick={(e) => props.handleClick(props.currentPath)}
      >
        <FavoriteIcon.react
          className={FAVORITE_BREADCRUMB_ICON_CLASS}
          tag="span"
        />
      </div>
    );
  }
  return null;
};

export class FavoritesWidget extends ReactWidget {
  private manager: FavoritesManager;
  private filebrowser: FileBrowser;
  private pathChanged = new Signal<this, string>(this);
  private breadcrumbIndex: number;

  constructor(manager: FavoritesManager, filebrowser: FileBrowser) {
    super();
    this.manager = manager;
    this.filebrowser = filebrowser;
    this.addClass(FAVORITE_MAIN_CLASS);
    
    console.log('FavoritesWidget constructor');

    this.filebrowser.model.pathChanged.connect((_, changedArgs) => {
      const path = changedArgs.newValue;
      this.pathChanged.emit(path);
    });
    
    const layout = filebrowser.layout;
    
    layout.widgets.forEach((widget, index) => {
      console.log([widget.node.className, index]);
      if (widget.node.className.includes(BREADCRUMB_CLASS)) {
        this.breadcrumbIndex = index + 1;
        return; // no reason to continue to iterate once the className is found
      }
    });
  }

  handlePinnerClick(path: string) {
    const shouldRemove = this.manager.hasFavorite(path);
    if (shouldRemove) {
      this.manager.removeFavorite(path);
    } else {
      const favorite = {
        root: this.manager.serverRoot,
        contentType: 'directory',
        iconLabel: folderIcon.name,
        path,
      } as IFavorites.Favorite;
      this.manager.addFavorite(favorite);
    }
  }

  render() {
    console.log(this.manager.isVisible());
    
    // insert the favorite icon for the current path breadcrumb component
      
    let favoritesBreadCrumb = (
      <UseSignal
        signal={this.pathChanged}
        initialSender={this}
        initialArgs={this.filebrowser.model.path}
      >
        {(widget: FavoritesWidget, currentPath: string) => (
          <FavoritesBreadCrumbs
            currentPath={currentPath}
            handleClick={widget.handlePinnerClick}
            manager={widget.manager}
          />
        )}
      </UseSignal>
    );
    
    if (favoritesBreadCrumb) {
        //;
    }
    
    
    
    return (
      <UseSignal
        signal={this.manager.favoritesChanged}
        initialSender={this.manager}
        initialArgs={this.manager.visibleFavorites()}
      >
        {(
          manager: FavoritesManager,
          visibleFavorites: Array<IFavorites.Favorite>
        ) => (
          <div>
            <UseSignal
              signal={manager.visibilityChanged}
              initialSender={manager}
              initialArgs={manager.isVisible()}
            >
              {(manager: FavoritesManager, isVisible: boolean) =>
                isVisible && (
                  <>
                    <div className={FAVORITE_HEADER_CLASS}>Favorites</div>
                    <div className={FAVORITE_CONTAINER_CLASS}>
                      {visibleFavorites.map((f) => (
                        <FavoriteComponent
                          key={`favorites-item-${f.path}`}
                          favorite={f}
                          handleClick={manager.handleClick.bind(manager)}
                        />
                      ))}
                    </div>
                    <div className={FILEBROWSER_HEADER_CLASS}>File Browser</div>
                  </>
                )
              }
            </UseSignal>
            {/*
            <UseSignal
              signal={this.pathChanged}
              initialSender={this}
              initialArgs={this.filebrowser.model.path}
            >
              {(widget: FavoritesWidget, currentPath: string) => (
                <FavoritesBreadCrumbs
                  currentPath={currentPath}
                  handleClick={widget.handlePinnerClick}
                  manager={widget.manager}
                />
              )}
            </UseSignal>
            */}
          </div>
        )}
      </UseSignal>
    );
  }
}
